package kr.ac.kookmin.cs;
public class PPoint {
int xA;
int yA;
public PPoint(int x, int y) {
xA = x;
yA = y;
};
public int getX() {
return xA;
}
public int getY() {
return yA;
}
}

/**
@version 1.01 2004-02-21
@author C H
*/

/**
This method attempts to grow an array by allocating a
new array and copying all elements.
@param a the array to grow
@return a larger array that contains all elements of a.
However, the returned array has type Object[], not
the same type as a
*/

/**
This method grows an array by allocating a
new array of the same type and copying all elements.
@param a the array to grow. This can be an object array
or a fundamental type array
@return a larger array that contains all elements of a.
*/

/**
A convenience method to print all elements in an array
@param a the array to print. can be an object array
or a fundamental type array
*/